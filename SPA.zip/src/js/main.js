import { routes } from "./routes.js";

const MAIN_OUTLET_ID = "content";
const SUBPAGE_OUTLET_ID = "subPageContent";

const LOGIN_PLACEHOLDER_HTML = `
  <div class="login-required">
    <p>Pro zobrazení této stránky se přihlaste.</p>
  </div>
`;

// Načtení HTML souboru
async function fetchHtml(path) {
  const resp = await fetch(path);

  if (!resp.ok) {
    throw new Error(`Chyba při načítání "${path}": ${resp.status} ${resp.statusText}`);
  }

  return await resp.text();
}

function getCurrentHash() {
  let hash = window.location.hash;

  if (!hash) {
    hash = "#Home";
    window.location.hash = hash;
  }
  return hash;
}

// Pomocná funkce na vykreslení do konkrétního outletu
function renderInto(outletId, html) {
  const el = document.getElementById(outletId);
  if (!el) {
    console.error(`Element s id="${outletId}" nebyl nalezen.`);
    return;
  }
  el.innerHTML = html;
}

// Hlavní loader podle hashe
async function loadByHash(hash) {
  let route = routes[hash];

  // neznámý hash → přesměruj na Home
  if (!route) {
    console.warn(`Route pro hash "${hash}" nenalezena, přesměrovávám na #Home`);
    window.location.hash = "#Home";
    route = routes["#Home"];
  }

  // Pokud má route parent, nejdřív načteme parent do MAIN_OUTLET
  if (route.parent) {
    const parentRoute = routes[route.parent];
    if (!parentRoute) {
      console.error(`Parent route "${route.parent}" nenalezena.`);
    } else {
      // pokud je parent chráněný, zobrazíme hlášku v hlavním contentu a skončíme
      if (parentRoute.requiresPassword) {
        renderInto(MAIN_OUTLET_ID, LOGIN_PLACEHOLDER_HTML);
        return;
      }

      try {
        const parentHtml = await fetchHtml(parentRoute.path);
        renderInto(MAIN_OUTLET_ID, parentHtml);
      } catch (err) {
        console.error(err);
        renderInto(MAIN_OUTLET_ID, `<p>Chyba při načítání parent stránky.</p>`);
        return;
      }
    }
  }

  // Určíme, kam se má obsah (nebo hláška) vykreslit
  const outletId = route.parent ? SUBPAGE_OUTLET_ID : MAIN_OUTLET_ID;

  // Pokud je route chráněná, místo HTML šablony vykreslíme hlášku
  if (route.requiresPassword) {
    renderInto(outletId, LOGIN_PLACEHOLDER_HTML);
    return;
  }

  // Normální veřejná stránka → načíst HTML soubor
  try {
    const html = await fetchHtml(route.path);
    renderInto(outletId, html);
  } catch (err) {
    console.error(err);
    renderInto(outletId, `<p>Chyba při načítání stránky.</p>`);
  }
}

async function handleHashChange() {
  const hash = getCurrentHash();
  await loadByHash(hash);
}

function initRouter() {
  handleHashChange();
  window.addEventListener("hashchange", handleHashChange);
}

document.addEventListener("DOMContentLoaded", initRouter);
