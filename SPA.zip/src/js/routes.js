// src/js/routes.js
export const routes = {
  "#Home": {
    path: "src/features/Home/home.html",
    requiresPassword: false
  },
  "#Tools": {
    path: "src/features/Tools/tools.html",
    requiresPassword: false
  },

  // SubPage pro Tools – načte se do #subPageContent
  "#pckDtbSearch": {
    path: "src/features/Tools/pckDtbView.html",
    requiresPassword: true,   // ← tady stačí přepnout na true
    parent: "#Tools"          // parent route, obsah se natáhne do subPageContent
  }

  // další subPages:
  // "#něco": { path: "…", parent: "#Tools", requiresPassword: false }
};
